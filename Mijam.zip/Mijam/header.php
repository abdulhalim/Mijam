<?php if (! defined('__TYPECHO_ROOT_DIR__')) {exit;}?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

     <link rel="icon" href="<?php $this->options->faviconUrl() ? $this->options->faviconUrl() : $this->options->themeUrl('images/favicon.png'); ?>" type="image/png" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Code:wght@300..700&family=Noto+Sans+SC:wght@100..900&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/default.min.css" />

    <link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>" />

    <?php $this->header(); ?>

    <title>
        <?php if ($this->is('index')): ?>
<?php $this->options->title(); ?>
<?php else: ?>
<?php $this->archiveTitle([], '', ''); ?> -<?php $this->options->title(); ?>
<?php endif; ?>
    </title>
</head>

<body>
<div class="site-wrapper">
    <header class="site-header">
        <div class="container header-container">
            <div class="logo">
                <a href="<?php $this->options->siteUrl(); ?>">
                    <?php if ($this->options->headerLogoUrl): ?>
                        <img src="<?php $this->options->headerLogoUrl(); ?>" alt="<?php $this->options->title(); ?>">
                    <?php else: ?>
                        <img src="<?php $this->options->themeUrl('images/logo.png'); ?>" alt="<?php $this->options->title(); ?>">
                    <?php endif; ?>
                </a>
            </div>

            <button class="hamburger-menu" aria-label="Main Menu">
                <span></span><span></span><span></span>
            </button>

            <nav class="main-menu">

                <div class="mobile-search-form">
                    <form class="smart-search" method="get" action="<?php $this->options->siteUrl(); ?>">
                        <input type="text" name="s" placeholder="Search..." aria-label="Search">
                        <button type="submit" aria-label="Search">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85zm-5.242 1.106a5 5 0 1 1 0-10 5 5 0 0 1 0 10z"/>
                            </svg>
                        </button>
                    </form>
                </div>

                <ul>
                    <?php
                        $showCategoryIdsStr = $this->options->showCategoryIds ?: '';
                        $showCategoryIds    = array_filter(array_map('trim', explode(',', $showCategoryIdsStr)));
                        $this->widget('Widget_Metas_Category_List', 'hideEmpty=true')->to($categories);
                        while ($categories->next()):
                            if (in_array($categories->mid, $showCategoryIds)):
                        ?>
				                                                                                        <li><a href="<?php $categories->permalink(); ?>"><?php $categories->name(); ?></a></li>
				                                                                                    <?php
                                                                                                        endif;
                                                                                                        endwhile;
                                                                                                        $this->widget('Widget_Contents_Page_List')->to($pages);
                                                                                                        while ($pages->next()):
                                                                                                    ?>
                        <li><a href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a></li>
                    <?php endwhile; ?>
                </ul>
            </nav>

            <button class="search-toggle" aria-label="Search">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
  <g transform="scale(-1, 1) translate(-16, 0)">
    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85zm-5.242 1.106a5 5 0 1 1 0-10 5 5 0 0 1 0 10z"/>
  </g>
</svg>

            </button>

        </div>
    </header>

<div class="search-fullscreen">
  <form class="search-form" method="get" action="<?php $this->options->siteUrl(); ?>">
    <button type="button" class="search-close" aria-label="Close">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
    <input type="text" name="s" placeholder="Search..." aria-label="Search">
    <button type="submit">Submit</button>
  </form>
</div>

    <div class="menu-overlay"></div>

    <main class="container main-content">
