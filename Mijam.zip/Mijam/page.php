<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>
<?php $this->need('header.php'); ?>

<main class="container main-wrapper">
    <div class="main-content">
        <article class="single-post">
            <?php if ($this->fields->thumbnail): ?>
<div class="post-thumbnail">
    <img src="<?php echo $this->fields->thumbnail; ?>" alt="<?php $this->title(); ?>">
</div>
<?php endif; ?>
            <div class="single-post-content">

                <div class="single-post-body">
                    <?php $this->content(); ?>
                </div>
            </div>
        </article>
    </div>
</main>

<?php $this->need('footer.php'); ?>