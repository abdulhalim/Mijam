// دکمه بازگشت به بالا
document.addEventListener('DOMContentLoaded', function() {
  const backToTopBtn = document.getElementById("backToTopBtn");

  if (backToTopBtn) {
    window.addEventListener('scroll', function() {
      if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
        backToTopBtn.style.display = "flex";  // برای هماهنگی با CSS قبلی
      } else {
        backToTopBtn.style.display = "none";
      }
    });

    backToTopBtn.addEventListener("click", function() {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // کد منوی موبایل
  const hamburger = document.querySelector('.hamburger-menu');
  const mainMenu = document.querySelector('.main-menu');
  const body = document.body;

  hamburger?.addEventListener('click', function() {
    hamburger.classList.toggle('active');
    mainMenu?.classList.toggle('active');
    body.classList.toggle('no-scroll');
  });



  // 2. جستجوی تمام صفحه
  const searchToggle = document.querySelector('.search-toggle');
  const searchFullscreen = document.querySelector('.search-fullscreen');
  const searchClose = document.querySelector('.search-close');
  const searchForm = document.querySelector('.search-form');
  const searchInput = document.querySelector('.search-form input[name="s"]');

  if (searchToggle && searchFullscreen && searchClose && searchForm && searchInput) {
    searchToggle.addEventListener('click', () => {
      searchFullscreen.classList.add('active');
      searchInput.focus();
    });

    searchClose.addEventListener('click', () => {
      searchFullscreen.classList.remove('active');
    });

    searchForm.addEventListener('click', (e) => e.stopPropagation());
    searchFullscreen.addEventListener('click', () => searchFullscreen.classList.remove('active'));
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') searchForm.submit();
    });
  }

  // 3. فهرست مطالب (TOC)
  const tocContainer = document.querySelector('.toc-container');
  const tocToggle = document.querySelector('.toc-toggle');
  const tocNav = document.querySelector('.toc-nav');
  const headings = document.querySelectorAll('.single-post-body h1, .single-post-body h2, .single-post-body h3');

  if (headings.length === 0 && tocContainer) {
    tocContainer.style.display = 'none';
  } else if (tocContainer && tocToggle && tocNav) {
    tocContainer.style.display = 'block';
    headings.forEach((heading, index) => {
      if (!heading.id) heading.id = `heading-${index}`;
      const link = document.createElement('a');
      link.href = `#${heading.id}`;
      link.textContent = heading.textContent;
      link.className = `toc-link toc-level-${heading.tagName.toLowerCase()}`;
      tocNav.appendChild(link);
    });
    tocNav.hidden = true;
    tocToggle.addEventListener('click', () => {
      const isExpanded = tocToggle.getAttribute('aria-expanded') === 'true';
      tocToggle.setAttribute('aria-expanded', String(!isExpanded));
      tocNav.hidden = !tocNav.hidden;
      tocNav.classList.toggle('show', !tocNav.hidden);
    });
  }

  // 4. هایلایت کد و دکمه کپی
  if (typeof hljs !== 'undefined') {
    document.querySelectorAll('pre code').forEach((block) => hljs.highlightElement(block));
  }

  document.querySelectorAll('pre').forEach((preBlock) => {
    preBlock.classList.add('code-block');
    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-button';
    copyBtn.textContent = 'Copy';
    copyBtn.addEventListener('click', () => {
      const code = preBlock.querySelector('code').innerText;
      navigator.clipboard.writeText(code).then(() => {
        copyBtn.textContent = 'Copied!';
        setTimeout(() => (copyBtn.textContent = 'Copy'), 1500);
      });
    });
    preBlock.appendChild(copyBtn);
  });
});

// 5. تابع عمومی کپی لینک
function copyLink(link) {
  navigator.clipboard.writeText(link).then(() => alert('Link copied!'));
}






document.addEventListener('DOMContentLoaded', function () {
  // همه تصاویر داخل محتوای پست را انتخاب کنید
  const postContent = document.querySelector('.single-post-body');
  if (!postContent) return;

  postContent.querySelectorAll('img').forEach(function(img) {
    const src = img.getAttribute('src');

    // اگر والد img لینک نیست، یک <a> دور img اضافه شود
    if (!img.parentElement || img.parentElement.tagName.toLowerCase() !== 'a') {
      const link = document.createElement('a');
      link.href = src;
      link.setAttribute('data-lightbox', 'post-gallery');  // نام گروه لایتباکس
      img.parentNode.insertBefore(link, img);
      link.appendChild(img);
    }
  });
});
