<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>

<div class="comments-section container">
    <?php $this->comments()->to($comments); ?>

    <?php if ($comments->have()): ?>
        <h3><?php $this->commentsNum('0 Comment', '1 Comment', '%d Comments'); ?></h3>

        <?php while ($comments->next()): ?>
    <div class="comment-block" id="comment-<?php $comments->theId(); ?>">

<div class="comment-header" style="display: flex; gap: 10px; align-items: flex-start;">
    <div class="comment-avatar" style="flex-shrink: 0;">
        <a href="<?php $this->options->siteUrl(); ?>author/<?php echo $comments->authorId; ?>/">
            <?php $comments->gravatar('50', 'mm', ''); ?>
        </a>
    </div>
    <div class="comment-body" style="flex: 1; display: flex; flex-direction: column;">
        <div class="comment-top" style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
            <div class="comment-author" style="font-weight: bold; line-height: 1;">
                <a href="<?php $this->options->siteUrl(); ?>author/<?php echo $comments->authorId; ?>/">
                    <?php echo htmlspecialchars($comments->author, ENT_QUOTES, 'UTF-8'); ?>
                </a>
            </div>
            <div class="comment-meta" style="color: #666; font-size: 0.85em; line-height: 1; text-align: right;">
                <?php $comments->date('Y/m/d - H:i'); ?>
            </div>
        </div>
        <div class="comment-content" style="margin-top: 6px; line-height: 1.4;">
            <?php $comments->content(); ?>
        </div>
    </div>
</div>

    </div>
<?php endwhile; ?>

        <?php $comments->pageNav( '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11 1L3 8l8 7" />
      </svg>','<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                   <path d="M5 1l8 7-8 7" />
           </svg>'); ?>

<?php endif; ?>

    <?php if ($this->allow('comment')): ?>
        <div id="<?php $this->respondId(); ?>" class="comment-form-block">
            <div class="cancel-comment-reply">
                <?php $comments->cancelReply(); ?>
            </div>

            <h3 id="response">Leave a Comment</h3>

            <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" role="form">
                <?php if ($this->user->hasLogin()): ?>
                    <p>Logged in as, <?php $this->user->screenName(); ?>!
                        <a href="<?php $this->options->logoutUrl(); ?>">[Log Out]</a>
                    </p>
                <?php else: ?>
                    <input type="text" name="author" id="author" placeholder="Name*" value="<?php $this->remember('author'); ?>" required>
                    <input type="email" name="mail" id="mail" placeholder="Email*" value="<?php $this->remember('mail'); ?>" required>
                    <input type="url" name="url" id="url" placeholder="Website URL" value="<?php $this->remember('url'); ?>">
                <?php endif; ?>

                <textarea rows="5" name="text" id="textarea" placeholder="Leave your comment here*" required><?php $this->remember('text'); ?></textarea>

                <button type="submit">Submit</button>
            </form>
        </div>
    <?php else: ?>
        <h3>Comments for this post are closed</h3>
    <?php endif; ?>
</div>
