<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>
<?php $this->need('header.php'); ?>

<div class="tag-header">
  <h1 class="tag-title">
    <span class="dot" style="background-color: hsl(210, 75%, 50%);"></span>
    Search results for:                                                                                                                                                                    <?php $this->archiveTitle([], '', ''); ?>
  </h1>
  <div class="tag-count">-                                                                                                                                   <?php echo $this->getTotal(); ?> Result(s) -</div>
</div>

<div class="tag-divider"></div>

<div class="tag-post-list">
  <?php if ($this->have()): ?>
    <ul>
      <?php while ($this->next()): ?>
        <li>
          <a href="<?php $this->permalink(); ?>">
            <span class="dot" style="background-color:                                                                                                                                                                                                                                                                               <?php echo getCategoryColor($this->cid); ?>;"></span>
            <?php $this->title(); ?>
          </a>
        </li>
      <?php endwhile; ?>
    </ul>
  <?php else: ?>

    <p class="center">Sorry, we couldn't find anything matching your search.</p>

    <div class="google-search-box">
      <div class="google-search-card">
	<p>You might have better luck searching on <strong>Google</strong></p>
        <form id="google-search" action="https://www.google.com/search" method="get" target="_blank">
          <input type="text" name="query" value="<?php echo htmlspecialchars($this->archiveTitle([], '', '')); ?>" placeholder="Search..." required />
          <button type="submit">Google it</button>
        </form>
      </div>
    </div>

    <script>
      document.getElementById('google-search').addEventListener('submit', function(e) {
        e.preventDefault();
        const input = this.query.value.trim();
        if (input) {
          const q = 'site:<?php echo $_SERVER['HTTP_HOST']; ?> ' + input;
          window.open('https://www.google.com/search?q=' + encodeURIComponent(q), '_blank');
        }
      });
    </script>

  <?php endif; ?>
</div>

<div class="clean-pagination">
  <?php $this->pageNav(
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11 1L3 8l8 7" />
      </svg>',
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M5 1l8 7-8 7" />
      </svg>',
          3,
          '...',
          [
              'wrapTag'   => 'ul',
              'wrapClass' => 'page-numbers',
              'itemTag'   => 'li',
              'textTag'   => 'span',
          ]
  ); ?>
</div>

<?php $this->need('footer.php'); ?>
