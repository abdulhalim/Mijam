<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit();
}?>
<?php $this->need('header.php'); ?>

<main class="container main-content">
  <div class="author-header">
    <div class="author-avatar-big">
      <img src="https://www.gravatar.com/avatar/<?php echo md5(strtolower(trim($this->author->mail))); ?>?s=120" alt="<?php $this->author(); ?>">
    </div>

    <h1 class="author-header-name"><?php $this->author(); ?></h1>

    <div class="author-stats-inline">
      <span><span class="dot dot-posts"></span><?php echo getAuthorPostsCount($this->author->uid); ?> Post(s)</span>
      <span><span class="dot dot-comments"></span><?php echo getAuthorCommentsCount($this->author->uid); ?> Comment(s)</span>
      <span><span class="dot dot-join"></span> Member Since:                                                                                                                                                                                                                                                                                                     <?php echo getUserJoinDate($this->author->uid); ?></span>
      <span><span class="dot dot-login"></span>Last Seen:                                                                                                                                                                                                                                                                                                                                          <?php echo getUserLastLogin($this->author->uid); ?></span>
    </div>
  </div>

  <section class="author-posts-section">
    <h2 class="author-posts-title">Articles by                                                                                                                                                                                                                                                                                                                                             <?php $this->author(); ?></h2>
    <div class="divider"></div>
    <?php if ($this->have()): ?>
      <ul class="author-posts-list">
        <?php while ($this->next()): ?>
          <li><a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></li>
        <?php endwhile; ?>
      </ul>
    <?php else: ?>
      <p>No articles have been published by this author.</p>
    <?php endif; ?>
  </section>

<div class="clean-pagination">
  <?php $this->pageNav(
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11 1L3 8l8 7" />
      </svg>',
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M5 1l8 7-8 7" />
      </svg>',
          3,
          '...',
          [
              'wrapTag'   => 'ul',
              'wrapClass' => 'page-numbers',
              'itemTag'   => 'li',
              'textTag'   => 'span',
          ]
  ); ?>
</div>
</main>

<?php $this->need('footer.php'); ?>
