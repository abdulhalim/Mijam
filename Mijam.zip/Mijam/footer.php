</main>

    <footer>
        <div class="container footer-container">
            <?php if ($this->options->footerLogoUrl || true): ?>
                <div class="footer-logo">
                    <img src="<?php echo $this->options->footerLogoUrl ? $this->options->footerLogoUrl : $this->options->themeUrl('images/footer-logo.png'); ?>" alt="Footer Logo">
                </div>
            <?php endif; ?>
<p>Made with Chai ☕️ by <a href="https://pourdaryaei.ir" target="_blank">Pourdaryaei</a></p>


            <p>&copy;<?php echo date('Y'); ?><?php $this->options->title(); ?> All right reserved.</p>
        </div>
    </footer>
</div>

<button id="backToTopBtn" title="‌Back to Top">
  <svg width="20" height="20" viewBox="0 0 100 100" fill="currentColor">
    <polygon points="50,20 90,80 10,80"/>
  </svg>
</button>

<?php $this->footer(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/highlight.min.js"></script>

    <script src="<?php $this->options->themeUrl('js/scripts.js'); ?>"></script>

</body>
</html>
