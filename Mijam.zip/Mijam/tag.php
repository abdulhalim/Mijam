<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>
<?php $this->need('header.php'); ?>

<?php

    $tagMid   = getArchiveTagId($this);
    $tagColor = getTagColor($tagMid);
?>

<div class="tag-header">
  <h1 class="tag-title">
  <span class="dot" style="background-color:                                                                                                                                                                                                                                                                                                                                                                                                                                                         <?php echo $tagColor; ?>;"></span>
                           <?php $this->archiveTitle([], ' ', ' '); ?>
</h1>
  <div class="tag-count">-<?php echo $this->getTotal(); ?> Post(s) -</div>
</div>
<div class="divider"></div>

<div class="tag-post-list">
  <?php if ($this->have()): ?>
    <ul>
      <?php while ($this->next()): ?>
        <li>
          <a href="<?php $this->permalink(); ?>">
            <span class="dot" style="background-color:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             <?php echo $tagColor; ?>;"></span>
            <?php $this->title(); ?>
          </a>
        </li>
      <?php endwhile; ?>
    </ul>
  <?php else: ?>
    <p class="center">We couldn't find any posts matching this tag.</p>
  <?php endif; ?>
</div>

<div class="clean-pagination">
  <?php $this->pageNav(
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11 1L3 8l8 7" />
      </svg>',
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M5 1l8 7-8 7" />
      </svg>',
          3,
          '...',
          [
              'wrapTag'   => 'ul',
              'wrapClass' => 'page-numbers',
              'itemTag'   => 'li',
              'textTag'   => 'span',
          ]
  ); ?>
</div>

<?php $this->need('footer.php'); ?>
