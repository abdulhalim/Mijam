<?php
    /**
     * Simple theme for Typecho
     *
     * @package Mijam
     * @author Pourdaryaei
     * @version 1
     * @link https://pourdaryaei.ir
     */

    if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>
<?php $this->need('header.php'); ?>

<main class="container main-wrapper">
<div class="main-content">

<?php if ($this->have()): ?>
<?php

    if ($this
    ->options->indexViewMode == 'list'): ?>
<section class="list-posts with-sidebar">
<?php while ($this->next()): ?>

<article class="list-item image-right">
<div class="thumbnail">
<a href="<?php $this->permalink(); ?>">
<?php if ($this
        ->fields
    ->thumbnail): ?>
<img src="<?php $this
    ->fields
    ->thumbnail(); ?>" alt="<?php $this->title(); ?>">
<?php
else: ?>
<img src="<?php echo getFirstImage($this); ?>" alt="<?php $this->title(); ?>">
<?php
endif; ?>
</a>
</div>

<div class="content">
<h2><a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></h2>
<p><?php $this->excerpt(100, '...'); ?></p>

<div class="meta-bottom">
  <div class="meta-left">
    <span class="single-post-date">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        <path d="M7 2v2H5a2 2 0 00-2 2v2h18V6a2 2 0 00-2-2h-2V2h-2v2H9V2H7zm13 6H4v12a2 2 0 002 2h12a2 2 0 002-2V8zM6 12h5v5H6v-5z"/>
      </svg>
      <?php $this->date('Y/m/d'); ?>
    </span>
    <span class="meta-category">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        <path d="M4 4h16v2H4V4zm0 4h16v12H4V8zm2 2v8h12v-8H6z"/>
      </svg>
      <?php $this->category(', '); ?>
    </span>
  </div>

  <div class="meta-right">
    <a href="<?php $this->author->permalink(); ?>" class="author-link">
      <img src="https://www.gravatar.com/avatar/<?php echo md5(strtolower(trim($this->author->mail))); ?>?s=30" alt="<?php $this->author(); ?>" class="author-avatar" />
      <span class="author-name"><?php $this->author(); ?></span>
    </a>
  </div>
</div>

</div>
</article>

<?php
endwhile; ?>
</section>
<?php
else: ?>

   <section class="card-posts                                                                                                                                                                                                                                                                                                                                                             <?php echo $this->options->showSidebar == '1' ? 'with-sidebar' : 'full-width'; ?>">
                <?php while ($this->next()): ?>
                    <div class="card">
                        <div class="thumbnail">
                            <a href="<?php $this->permalink(); ?>">
                                <?php if ($this->fields->thumbnail): ?>
                                    <img src="<?php $this->fields->thumbnail(); ?>" alt="<?php $this->title(); ?>">
                                <?php else: ?>
                                    <img src="<?php echo getFirstImage($this); ?>" alt="<?php $this->title(); ?>">
                                <?php endif; ?>
                            </a>
                        </div>

                       <div class="content">
                                <h2><a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></h2>
                                <div><?php $this->excerpt(100, '...'); ?></div>

                                <div class="meta-bottom-custom">
                                    <div class="author-info-custom">
                                        <a href="<?php $this->author->permalink(); ?>" class="author-link-custom">
                                            <img src="https://www.gravatar.com/avatar/<?php echo md5(strtolower(trim($this->author->mail))); ?>?s=30" alt="<?php $this->author(); ?>" class="author-avatar-custom">
                                            <span class="author-name-custom"><?php $this->author(); ?></span>
                                        </a>
                                    </div>
                                    <span class="post-date-custom"><?php $this->date('Y/m/d'); ?></span>
                                </div>
                            </div>

                    </div>
                <?php endwhile; ?>
    </section>

<?php
endif; ?>

<div class="clean-pagination">
  <?php $this->pageNav(
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11 1L3 8l8 7" />
      </svg>',
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M5 1l8 7-8 7" />
      </svg>',
          3,
          '...',
          [
              'wrapTag'   => 'ul',
              'wrapClass' => 'page-numbers',
              'itemTag'   => 'li',
              'textTag'   => 'span',
          ]
  ); ?>
</div>

<?php
else: ?>

<div class="empty-state">
  <h2>🎉 We're glad you're here!</h2>
  <p>No posts have been published yet.</p>
  <?php if ($this->user->hasLogin()): ?>
    <p>Get started by writing your first post.</p>
    <a href="<?php $this->options->adminUrl('write-post.php'); ?>" class="btn">+ Write a New Article</a>
  <?php else: ?>
    <p>Please log in to create a post.</p>
    <a href="<?php $this->options->adminUrl('login.php'); ?>" class="btn">Login to Dashboard</a>
  <?php endif; ?>
</div>

<?php
endif; ?>

</div>

<?php
    $showSidebar = ($this
            ->options->indexViewMode == 'list') ? true : ($this
            ->options->showSidebar == '1');
    if ($showSidebar): ?>
<aside class="sidebar">
<?php $this->need('sidebar.php'); ?>
</aside>
<?php
endif; ?>

</main>

<?php $this->need('footer.php'); ?>
