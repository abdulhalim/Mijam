<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>

<section class="widget sidebar-search">
  <form method="post" action="<?php $this->options->siteUrl(); ?>">
    <div class="search-box">
      <input type="text" name="s" class="search-input" placeholder="Search..." required>
      <button type="submit" class="search-icon" aria-label="Search">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
  <g transform="scale(-1, 1) translate(-16, 0)">
    <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85zm-5.242 1.106a5 5 0 1 1 0-10 5 5 0 0 1 0 10z"/>
  </g>
</svg>

      </button>
    </div>
  </form>
</section>

<?php $showRecentWidget = $this->options->showRecentWidget == '1'; ?>

<?php if ($showRecentOnIndex && $this->is('index')): ?>
    <section class="widget">
        <h3 class="widget-title">Last Posts</h3>
        <ul class="recent-posts-list">
            <?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=4')->to($recent); ?>
<?php while ($recent->next()): ?>
<?php $thumbnail = $recent->fields->thumbnail ?: getFirstImage($recent); ?>
                <li class="recent-posts-item">
                    <a href="<?php $recent->permalink(); ?>" class="recent-post-item">
                        <img src="<?php echo $thumbnail; ?>" alt="<?php $recent->title(); ?>" class="recent-post-thumb">
                        <div class="recent-post-info">
                            <span class="recent-post-title"><?php $recent->title(); ?></span>
                            <span class="recent-post-date"><?php $recent->date('Y/m/d'); ?></span>
                        </div>
                    </a>
                </li>
            <?php endwhile; ?>
        </ul>
    </section>
<?php elseif (! $showRecentOnIndex): ?>
    <section class="widget">
        <h3 class="widget-title">Last Posts</h3>
        <ul class="recent-posts-list">
            <?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=4')->to($recent); ?>
<?php while ($recent->next()): ?>
<?php $thumbnail = $recent->fields->thumbnail ?: getFirstImage($recent); ?>
                <li class="recent-posts-item">
                    <a href="<?php $recent->permalink(); ?>" class="recent-post-item">
                        <img src="<?php echo $thumbnail; ?>" alt="<?php $recent->title(); ?>" class="recent-post-thumb">
                        <div class="recent-post-info">
                            <span class="recent-post-title"><?php $recent->title(); ?></span>
                            <span class="recent-post-date"><?php $recent->date('Y/m/d'); ?></span>
                        </div>
                    </a>
                </li>
            <?php endwhile; ?>
        </ul>
    </section>
<?php endif; ?>

<section class="widget">
  <h3 class="widget-title">Tag Clouds</h3>
  <div class="tag-list">
    <?php
        $this->widget('Widget_Metas_Tag_Cloud')->to($allTags);
        $tagsArray = [];
        while ($allTags->next()) {
            $tagsArray[] = [
                'name'      => $allTags->name,
                'permalink' => $allTags->permalink,
                'mid'       => $allTags->mid,
            ];
        }
        shuffle($tagsArray);
        $maxTags = 9;
        $count   = 0;
        foreach ($tagsArray as $tag):
            if ($count++ >= $maxTags) {
                break;
            }

            $color = getTagColor($tag['mid']);
        ?>
	      <a href="<?php echo $tag['permalink']; ?>" class="post-tag">
	        <span class="tag-dot" style="background-color:	                                                       <?php echo $color; ?>;"></span>
	        <?php echo htmlspecialchars($tag['name']); ?>
	      </a>
	    <?php endforeach; ?>
  </div>
</section>

<section class="widget sidebar-comments-widget">
    <h3 class="widget-title">Last Comments</h3>

    <ul class="recent-comments-list">
        <?php $this->widget('Widget_Comments_Recent', 'pageSize=4')->to($comments); ?>
<?php while ($comments->next()): ?>
            <li class="recent-comment-item">
                <a href="<?php $comments->permalink(); ?>#comment-<?php echo $comments->coid; ?>" class="recent-comment-link">
                    <?php
                        $authorEmail = $comments->mail;
                        $emailHash   = $authorEmail ? md5(strtolower(trim($authorEmail))) : md5('default@anonymous.com');
                        $avatarUrl   = "https://www.gravatar.com/avatar/{$emailHash}?s=38&d=mp";

                        if ($comments->authorId) {
                            $user       = Typecho_Widget::widget('Widget_Abstract_Users')->filter(['uid' => $comments->authorId]);
                            $authorName = ($user && isset($user->screenName)) ? $user->screenName : $comments->author;
                        } else {
                            $authorName = $comments->author;
                        }
                    ?>
                    <img src="<?php echo $avatarUrl; ?>" alt="<?php echo htmlspecialchars($authorName); ?> - author" class="comment-author-avatar" loading="lazy" />
                    <span class="comment-author-name"><?php echo htmlspecialchars($authorName); ?></span>
                    <span class="comment-excerpt"><?php echo $comments->excerpt(40, '...'); ?></span>
                </a>
            </li>
        <?php endwhile; ?>
    </ul>

</section>
