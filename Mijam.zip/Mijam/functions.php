<?php
if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

function themeFields($layout)
{
    $thumbnail = new Typecho_Widget_Helper_Form_Element_Text(
        'thumbnail', null, null, 'Featured Image URL', 'Leave blank to use the first image from the post.'
    );
    $layout->addItem($thumbnail);
}

function themeConfig($form)
{

    $headerLogoUrl = new Typecho_Widget_Helper_Form_Element_Text(
        'headerLogoUrl',
        null,
        Helper::options()->themeUrl . '/images/logo.png',
        'Header Logo URL',
        'Leave empty to use the default logo (images/logo.png).'
    );
    $form->addInput($headerLogoUrl);

    $footerLogoUrl = new Typecho_Widget_Helper_Form_Element_Text(
        'footerLogoUrl',
        null,
        Helper::options()->themeUrl . '/images/footer-logo.png',
        'Footer Logo URL',
        'Leave empty to use the default footer logo (images/footer-logo.png).'
    );
    $form->addInput($footerLogoUrl);

    $faviconUrl = new Typecho_Widget_Helper_Form_Element_Text(
        'faviconUrl',
        null,
        Helper::options()->themeUrl . '/images/favicon.png',
        'Favicon URL',
        'Leave empty to use the default favicon (images/favicon.png).'
    );
    $form->addInput($faviconUrl);

    $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
        'indexViewMode', ['card' => 'Card Layout', 'list' => 'List Layout'], 'card', 'Index Layouts'
    ));

    $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
        'showSidebar', ['1' => 'Enable', '0' => 'Disable'], '1', 'Enable sidebar for card layout'
    ));

    $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
        'showCategoryIds', null, '', 'Categories to Display in Menu',
        'Enter category IDs, separated by commas. Example: 1,3,5'
    ));
}

function getFirstImage($widget)
{
    if (preg_match('/<img.*?src=[\'"](.*?)[\'"]/i', $widget->content, $matches)) {
        return $matches[1];
    }
    return Helper::options()->themeUrl . '/images/default-thumb.jpg';
}

function getAuthorPostsCount($uid)
{
    $db    = Typecho_Db::get();
    $posts = $db->fetchObject(
        $db->select(['COUNT(*)' => 'count'])
            ->from('table.contents')
            ->where('authorId = ?', $uid)
            ->where('type = ?', 'post')
            ->where('status = ?', 'publish')
            ->where('password IS NULL')
    );
    return $posts->count;
}

function getAuthorCommentsCount($uid)
{
    $db       = Typecho_Db::get();
    $comments = $db->fetchObject(
        $db->select(['COUNT(*)' => 'count'])
            ->from('table.comments')
            ->where('authorId = ?', $uid)
            ->where('status = ?', 'approved')
    );
    return $comments->count;
}

function getUserJoinDate($uid)
{
    $db   = Typecho_Db::get();
    $user = $db->fetchRow(
        $db->select('created')
            ->from('table.users')
            ->where('uid = ?', $uid)
    );
    return date('Y/m/d', $user['created']);
}

function getUserLastLogin($uid)
{
    $db   = Typecho_Db::get();
    $user = $db->fetchRow(
        $db->select()->from('table.users')->where('uid = ?', $uid)
    );

    if ($user && $user['logged'] > 0) {
        return date('Y/m/d', $user['logged']);
    } else {
        return 'Not logged in yet';
    }
}

function getCategoryColor($cid)
{
    $hue = ($cid * 47) % 360;
    return "hsl($hue, 70%, 55%)";
}

function getTagColor($mid)
{
    $hue = ($mid * 37) % 360;
    return "hsl($hue, 75%, 50%)";
}

function getArchiveTagId($archive)
{
    if ($archive->is('tag') && method_exists($archive, 'getArchiveSlug')) {
        $db  = Typecho_Db::get();
        $tag = $db->fetchRow(
            $db->select()->from('table.metas')->where('slug = ?', $archive->getArchiveSlug())->limit(1)
        );
        if ($tag) {
            return $tag['mid'];
        }
    }
    return 0;
}

function getSelectedCategories()
{
    $options = Helper::options();
    $idsStr  = $options->showCategoryIds;
    if (! $idsStr) {
        return [];
    }

    $idsArr = array_filter(array_map('intval', explode(',', $idsStr)));
    return $idsArr;
}
