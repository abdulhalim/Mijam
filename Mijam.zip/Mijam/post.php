<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>
<?php $this->need('header.php'); ?>

<main class="container main-wrapper">

    <div class="main-content">
        <article class="single-post">

            <?php if ($this->fields->thumbnail): ?>
<div class="post-thumbnail">
    <img src="<?php echo $this->fields->thumbnail; ?>" alt="<?php $this->title(); ?>">
</div>
<?php endif; ?>

            <?php if ($this->options->showPostCover == '1'): ?>
                <div class="single-post-thumbnail">
                    <?php
                        if ($this->fields->thumbnail) {
                            $cover = $this->fields->thumbnail;
                        } else {
                            $cover = getFirstImage($this) ?: $this->options->defaultCover();
                        }
                    ?>
                    <img src="<?php echo $cover; ?>" alt="<?php $this->title(); ?>">
                </div>
            <?php endif; ?>

            <div class="single-post-content">

<?php

    if ($this->user->hasLogin()) {

        $isAdmin = $this->user->groupCheck('administrator');

        $isAuthor = ($this->author->uid == $this->user->uid);

        if ($isAdmin || $isAuthor):
    ?>
        <button id="editPostBtn" title="Edit Post" onclick="location.href='<?php $this->options->adminUrl('write-post.php?cid=' . $this->cid); ?>'">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1.003 1.003 0 000-1.42l-2.34-2.34a1.003 1.003 0 00-1.42 0l-1.83 1.83 3.75 3.75 1.84-1.82z"/>
            </svg>
        </button>
<?php
    endif;
    }
?>



                <h1 class="single-post-title"><?php $this->title(); ?></h1>

                <div class="single-post-meta">
                    <div class="meta-author">
                        <a href="<?php $this->author->permalink(); ?>" class="author-link">
      <img src="https://www.gravatar.com/avatar/<?php echo md5(strtolower(trim($this->author->mail))); ?>?s=30" alt="<?php $this->author(); ?>" class="author-avatar" />
      <span class="author-name"><?php $this->author(); ?></span>
    </a>
                    </div>
                    <div class="meta-info-group">
                        <span class="single-post-date">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M7 2v2H5a2 2 0 00-2 2v2h18V6a2 2 0 00-2-2h-2V2h-2v2H9V2H7zm13 6H4v12a2 2 0 002 2h12a2 2 0 002-2V8zM6 12h5v5H6v-5z"/>
                            </svg>
                            <?php $this->date('Y/m/d'); ?>
                        </span>
                        <span class="meta-category">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M4 4h16v2H4V4zm0 4h16v12H4V8zm2 2v8h12v-8H6z"/>
                            </svg>
                            <?php $this->category(', '); ?>
                        </span>
                    </div>
                </div>

                <div class="single-post-body">

                   <!-- TOC -->
                   <div class="toc-container">
                  <button class="toc-toggle">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" class="toc-icon">
                      <path d="M4 5h16v2H4V5zm0 6h16v2H4v-2zm0 6h16v2H4v-2z"/>
                    </svg>

                  </button>
                  <nav class="toc-nav"></nav>
                </div>

                    <?php $this->content(); ?>
                </div>

                <?php if ($this->tags): ?>
  <div class="single-post-tags">
    <?php foreach ($this->tags as $tag): ?>
<?php $color = getTagColor($tag['mid']); ?>
      <a class="post-tag" href="<?php echo $tag['permalink']; ?>">
        <span class="tag-dot" style="background-color:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   <?php echo $color; ?>;"></span>
        <?php echo htmlspecialchars($tag['name']); ?>
      </a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<div class="post-share-box">
    <span class="share-title">Share:</span>
    <div class="share-buttons">
        <a href="https://t.me/share/url?url=<?php $this->permalink(); ?>" target="_blank" class="share-btn telegram" title="Share on telegram">
            <img src="<?php $this->options->themeUrl('images/telegram.svg'); ?>" alt="Telegram" width="20" height="20">
        </a>
        <a href="https://twitter.com/intent/tweet?url=<?php $this->permalink(); ?>" target="_blank" class="share-btn twitter" title="Twitt">
            <img src="<?php $this->options->themeUrl('images/twitter.svg'); ?>" alt="Twitter" width="20" height="20">
        </a>
        <a href="https://api.whatsapp.com/send?text=<?php $this->permalink(); ?>" target="_blank" class="share-btn whatsapp" title="Whatsapp">
            <img src="<?php $this->options->themeUrl('images/whatsapp.svg'); ?>" alt="Whatsapp" width="20" height="20">
        </a>
        <button onclick="copyLink('<?php $this->permalink(); ?>')" class="share-btn copy" title="Copy URL">
            <img src="<?php $this->options->themeUrl('images/email.svg'); ?>" alt="Copy URL" width="20" height="20">
        </button>
    </div>
</div>

            </div>

        </article>

<ul class="post-navigation">
    <li class="nav-prev"><?php $this->thePrev('%s', 'Nothing to show'); ?></li>
    <li class="nav-next"><?php $this->theNext('%s', 'Nothing to show'); ?></li>
</ul>




        <?php $this->need('comments.php'); ?>
    </div>

    <aside class="sidebar">
    <?php $this->need('sidebar.php'); ?>
</aside>

</main>

<?php $this->need('footer.php'); ?>
