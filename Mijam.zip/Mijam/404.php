<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>
<?php $this->need('header.php'); ?>
<style>
body {
  background:
  margin: 0;
  padding: 0;
  font-family: "Roboto", "Noto Sans SC", sans-serif;
  direction: ltr;
}
.error-page-container {
  min-height: 75vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
}
.error-code {
  font-size: 8em;
  color:
  font-weight: 900;
  letter-spacing: 6px;
  margin: 0;
  margin-bottom: 0.2em;
  user-select: none;
  animation: wave 1.8s infinite alternate, blink 1s infinite steps(2, start);
}
@keyframes wave {
  0% { transform: scale(1) rotate(-3deg);}
  20%{ transform: scale(1.07,0.93) rotate(2deg);}
  40%{ transform: scale(0.96,1.08) rotate(-3deg);}
  60%{ transform: scale(1.06,0.95) rotate(2deg);}
  80%{ transform: scale(1.01) rotate(-2deg);}
  100% { transform: scale(1) rotate(0);}
}
@keyframes blink {
  0%, 100% { opacity: 1;}
  90% { opacity: 0.75;}
}
.error-message {
  font-size: 1.3em;
  color:
  margin-top: 0.5em;
  max-width: 90vw;
  line-height: 2;
}
</style>
<div class="error-page-container">
  <div class="error-code">404</div>
  <div class="error-message">
    The page you were looking for doesn't exist<br>
	Please check the URL or return to the homepage.
  </div>
</div>
<?php $this->need('footer.php'); ?>
