<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>
<?php $this->need('header.php'); ?>

<main class="container main-wrapper page-category">
    <section class="main-content">

        <?php

            $hue   = ($this->cid * 37) % 360;
            $color = "hsl($hue, 75%, 50%)";
        ?>

        <div class="category-header">
            <h1 class="category-title">
                <span class="dot" style="background-color:                                                                                                                                                                                                                                                                                                                                                             <?php echo $color; ?>;"></span>
                <?php $this->archiveTitle([], '', ''); ?>
            </h1>
            <div class="category-count">-                                                                                                                                                                                                                                                       <?php echo $this->getTotal(); ?> Post(s) -</div>
            <?php if ($this->getDescription()): ?>
                <p class="category-desc"><?php echo htmlspecialchars($this->getDescription()); ?></p>
            <?php endif; ?>
        </div>

        <?php if ($this->have()): ?>
            <div class="card-posts full-width">
                <?php while ($this->next()): ?>
                    <div class="card">
                        <div class="thumbnail">
                            <a href="<?php $this->permalink(); ?>">
                                <?php if ($this->fields->thumbnail): ?>
                                    <img src="<?php $this->fields->thumbnail(); ?>" alt="<?php $this->title(); ?>">
                                <?php else: ?>
                                    <img src="<?php echo getFirstImage($this); ?>" alt="<?php $this->title(); ?>">
                                <?php endif; ?>
                            </a>
                        </div>

                        <div class="content">
                            <h2><a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></h2>
                            <div><?php $this->excerpt(100, '...'); ?></div>

                            <div class="meta-bottom-custom">
                                <div class="author-info-custom">
                                    <a href="<?php $this->author->permalink(); ?>" class="author-link-custom">
                                        <img src="https://www.gravatar.com/avatar/<?php echo md5(strtolower(trim($this->author->mail))); ?>?s=30" alt="<?php $this->author(); ?>" class="author-avatar-custom">
                                        <span class="author-name-custom"><?php $this->author(); ?></span>
                                    </a>
                                </div>
                                <span class="post-date-custom"><?php $this->date('Y/m/d'); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>

<div class="clean-pagination">
  <?php $this->pageNav(
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11 1L3 8l8 7" />
      </svg>',
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M5 1l8 7-8 7" />
      </svg>',
          3,
          '...',
          [
              'wrapTag'   => 'ul',
              'wrapClass' => 'page-numbers',
              'itemTag'   => 'li',
              'textTag'   => 'span',
          ]
  ); ?>
</div>

        <?php else: ?>
            <p class="no-posts center">It looks like there's nothing here yet.</p>
        <?php endif; ?>

    </section>
</main>

<?php $this->need('footer.php'); ?>
