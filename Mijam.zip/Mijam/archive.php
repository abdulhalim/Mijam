<?php if (! defined('__TYPECHO_ROOT_DIR__')) {
        exit;
    }
?>
<?php $this->need('header.php'); ?>
<main class="container main-wrapper">
    <section class="main-content">
        <h1 class="archive-title">Article Archives</h1>
        <?php if ($this->have()): ?>
            <ul class="archive-list">
                <?php while ($this->next()): ?>
                    <li>
                        <a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
                    </li>
                <?php endwhile; ?>
            </ul>
        <div class="clean-pagination">
  <?php $this->pageNav(
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M11 1L3 8l8 7" />
      </svg>',
          '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path d="M5 1l8 7-8 7" />
      </svg>',
          3,
          '...',
          [
              'wrapTag'   => 'ul',
              'wrapClass' => 'page-numbers',
              'itemTag'   => 'li',
              'textTag'   => 'span',
          ]
  ); ?>
</div>
        <?php else: ?>
            <p class="center">No content has been published yet.</p>
        <?php endif; ?>
    </section>
</main>
<?php $this->need('footer.php'); ?>
